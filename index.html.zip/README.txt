Sociavela - projet HTML

Ouvrez index.html dans votre navigateur pour afficher la page principale.
Le tableau de bord est accessible depuis la page principale ou en ouvrant dashboard.html.
Gardez les quatre fichiers dans le meme dossier : i18n.js et dashboard-theme.js sont necessaires.

Les photos et les polices sont chargees depuis Internet.
